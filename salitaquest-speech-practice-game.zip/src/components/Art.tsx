// Inline SVG art — no external images, works offline.
// All illustrations are simple flat shapes with rounded corners.

export function WordArt({ art, className = "" }: { art: string; className?: string }) {
  switch (art) {
    case "lobo":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <ellipse cx="100" cy="88" rx="58" ry="48" fill="#8D99AE" />
          <path d="M52 58 L38 18 L72 38 Z" fill="#6C7A93" />
          <path d="M148 58 L162 18 L128 38 Z" fill="#6C7A93" />
          <ellipse cx="100" cy="104" rx="34" ry="24" fill="#EDF2F4" />
          <circle cx="78" cy="78" r="9" fill="#2D3142" /><circle cx="122" cy="78" r="9" fill="#2D3142" />
          <circle cx="81" cy="75" r="3" fill="#fff" /><circle cx="125" cy="75" r="3" fill="#fff" />
          <ellipse cx="100" cy="98" rx="10" ry="7" fill="#2D3142" />
          <path d="M100 105 Q100 114 90 114 M100 105 Q100 114 110 114" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "leon":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <circle cx="100" cy="84" r="62" fill="#FF9F45" />
          <circle cx="100" cy="84" r="62" fill="none" stroke="#E07B2A" strokeWidth="6" strokeDasharray="10 8" strokeLinecap="round" />
          <ellipse cx="100" cy="90" rx="44" ry="40" fill="#FFD9A0" />
          <circle cx="82" cy="80" r="8" fill="#2D3142" /><circle cx="118" cy="80" r="8" fill="#2D3142" />
          <ellipse cx="100" cy="98" rx="9" ry="6" fill="#2D3142" />
          <path d="M100 104 Q100 112 92 112 M100 104 Q100 112 108 112" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
          <circle cx="70" cy="96" r="7" fill="#FFB3B3" opacity=".8" /><circle cx="130" cy="96" r="7" fill="#FFB3B3" opacity=".8" />
        </svg>
      );
    case "litchi":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M100 22 Q108 8 122 10 Q112 22 100 22" fill="#2EC4B6" />
          <rect x="96" y="18" width="8" height="18" rx="4" fill="#7A4A2B" />
          <circle cx="100" cy="92" r="52" fill="#FF8FA3" />
          <circle cx="78" cy="72" r="7" fill="#FFB3C1" /><circle cx="112" cy="66" r="6" fill="#FFB3C1" /><circle cx="124" cy="96" r="7" fill="#FFB3C1" /><circle cx="84" cy="108" r="6" fill="#FFB3C1" /><circle cx="104" cy="116" r="5" fill="#FFB3C1" />
          <circle cx="84" cy="86" r="5" fill="#2D3142" /><circle cx="116" cy="86" r="5" fill="#2D3142" />
          <path d="M92 100 Q100 106 108 100" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "araw":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <g stroke="#FFC93C" strokeWidth="9" strokeLinecap="round">
            <line x1="100" y1="8" x2="100" y2="28" /><line x1="100" y1="132" x2="100" y2="152" />
            <line x1="18" y1="80" x2="38" y2="80" /><line x1="162" y1="80" x2="182" y2="80" />
            <line x1="42" y1="22" x2="56" y2="36" /><line x1="144" y1="124" x2="158" y2="138" />
            <line x1="158" y1="22" x2="144" y2="36" /><line x1="56" y1="124" x2="42" y2="138" />
          </g>
          <circle cx="100" cy="80" r="42" fill="#FFC93C" stroke="#FF9F45" strokeWidth="5" />
          <circle cx="86" cy="74" r="5" fill="#2D3142" /><circle cx="114" cy="74" r="5" fill="#2D3142" />
          <path d="M88 88 Q100 98 112 88" stroke="#2D3142" strokeWidth="4" fill="none" strokeLinecap="round" />
          <circle cx="76" cy="86" r="6" fill="#FF9F45" opacity=".7" /><circle cx="124" cy="86" r="6" fill="#FF9F45" opacity=".7" />
        </svg>
      );
    case "rosas":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M100 160 Q96 120 100 96" stroke="#2EC4B6" strokeWidth="8" fill="none" strokeLinecap="round" />
          <ellipse cx="78" cy="126" rx="20" ry="10" fill="#2EC4B6" transform="rotate(-24 78 126)" />
          <ellipse cx="122" cy="134" rx="20" ry="10" fill="#2EC4B6" transform="rotate(24 122 134)" />
          <g fill="#FF6B6B">
            <circle cx="100" cy="52" r="30" /><circle cx="74" cy="70" r="24" /><circle cx="126" cy="70" r="24" /><circle cx="84" cy="88" r="22" /><circle cx="116" cy="88" r="22" />
          </g>
          <circle cx="100" cy="72" r="20" fill="#FF8FA3" />
          <path d="M92 68 Q100 62 108 68 M90 78 Q100 84 110 78" stroke="#C94F4F" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "barko":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M20 118 Q100 138 180 118 L168 92 L32 92 Z" fill="#FF6B6B" />
          <rect x="30" y="104" width="140" height="10" rx="5" fill="#fff" />
          <rect x="94" y="28" width="10" height="66" rx="5" fill="#7A4A2B" />
          <path d="M104 32 L104 88 L148 88 Z" fill="#fff" stroke="#2EC4B6" strokeWidth="4" strokeLinejoin="round" />
          <path d="M94 40 L94 88 L58 88 Z" fill="#FFC93C" stroke="#FF9F45" strokeWidth="4" strokeLinejoin="round" />
          <path d="M10 138 Q30 128 50 138 T90 138 T130 138 T170 138 T200 138" stroke="#2EC4B6" strokeWidth="7" fill="none" strokeLinecap="round" />
          <circle cx="70" cy="100" r="5" fill="#2D3142" /><circle cx="100" cy="100" r="5" fill="#2D3142" /><circle cx="130" cy="100" r="5" fill="#2D3142" />
        </svg>
      );
    case "kabayo":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <ellipse cx="100" cy="96" rx="56" ry="42" fill="#C68B59" />
          <path d="M62 70 Q58 30 84 22 Q78 48 84 66 Z" fill="#7A4A2B" />
          <path d="M138 70 Q142 30 116 22 Q122 48 116 66 Z" fill="#7A4A2B" />
          <ellipse cx="100" cy="112" rx="30" ry="20" fill="#E8C39E" />
          <circle cx="80" cy="84" r="8" fill="#2D3142" /><circle cx="120" cy="84" r="8" fill="#2D3142" />
          <circle cx="83" cy="81" r="3" fill="#fff" /><circle cx="123" cy="81" r="3" fill="#fff" />
          <ellipse cx="100" cy="104" rx="9" ry="6" fill="#2D3142" />
          <path d="M100 110 Q100 118 92 118 M100 110 Q100 118 108 118" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "kalabaw":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M48 62 Q20 44 28 22 Q52 30 62 50 Z" fill="#E8E0D0" stroke="#B8A88A" strokeWidth="4" />
          <path d="M152 62 Q180 44 172 22 Q148 30 138 50 Z" fill="#E8E0D0" stroke="#B8A88A" strokeWidth="4" />
          <ellipse cx="100" cy="92" rx="58" ry="48" fill="#8D99AE" />
          <ellipse cx="100" cy="108" rx="34" ry="24" fill="#C9D1DB" />
          <circle cx="78" cy="82" r="9" fill="#2D3142" /><circle cx="122" cy="82" r="9" fill="#2D3142" />
          <circle cx="81" cy="79" r="3" fill="#fff" /><circle cx="125" cy="79" r="3" fill="#fff" />
          <ellipse cx="100" cy="102" rx="11" ry="7" fill="#2D3142" />
          <path d="M100 109 Q100 117 91 117 M100 109 Q100 117 109 117" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "kambing":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M64 52 Q48 20 68 14 Q72 36 78 50 Z" fill="#E8E0D0" />
          <path d="M136 52 Q152 20 132 14 Q128 36 122 50 Z" fill="#E8E0D0" />
          <ellipse cx="100" cy="92" rx="54" ry="46" fill="#F5F0E6" stroke="#D9CFC0" strokeWidth="4" />
          <ellipse cx="100" cy="110" rx="26" ry="18" fill="#E8E0D0" />
          <circle cx="80" cy="84" r="8" fill="#2D3142" /><circle cx="120" cy="84" r="8" fill="#2D3142" />
          <ellipse cx="100" cy="104" rx="8" ry="5" fill="#2D3142" />
          <path d="M100 109 Q100 116 93 116 M100 109 Q100 116 107 116" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M84 128 Q100 138 116 128" stroke="#B8A88A" strokeWidth="4" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "sasakyan":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M100 10 Q128 34 132 78 L68 78 Q72 34 100 10 Z" fill="#FF6B6B" />
          <circle cx="100" cy="52" r="16" fill="#BDE0FE" stroke="#2D3142" strokeWidth="4" />
          <path d="M68 78 L40 108 Q36 124 52 122 L68 108 Z" fill="#FFC93C" />
          <path d="M132 78 L160 108 Q164 124 148 122 L132 108 Z" fill="#FFC93C" />
          <rect x="62" y="78" width="76" height="34" rx="12" fill="#2EC4B6" />
          <circle cx="82" cy="95" r="7" fill="#fff" /><circle cx="100" cy="95" r="7" fill="#fff" /><circle cx="118" cy="95" r="7" fill="#fff" />
          <path d="M86 128 Q100 148 114 128 Q100 136 86 128" fill="#FF9F45" />
          <path d="M92 132 Q100 146 108 132" fill="#FFC93C" />
        </svg>
      );
    case "bituin":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M100 14 L118 58 L166 60 L128 90 L142 136 L100 110 L58 136 L72 90 L34 60 L82 58 Z" fill="#FFC93C" stroke="#FF9F45" strokeWidth="5" strokeLinejoin="round" />
          <circle cx="88" cy="76" r="5" fill="#2D3142" /><circle cx="112" cy="76" r="5" fill="#2D3142" />
          <path d="M90 88 Q100 96 110 88" stroke="#2D3142" strokeWidth="4" fill="none" strokeLinecap="round" />
          <circle cx="76" cy="86" r="6" fill="#FF9F45" opacity=".7" /><circle cx="124" cy="86" r="6" fill="#FF9F45" opacity=".7" />
        </svg>
      );
    case "buwan":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M132 18 A64 64 0 1 0 132 142 A50 50 0 1 1 132 18 Z" fill="#FFE66D" stroke="#FFC93C" strokeWidth="5" strokeLinejoin="round" />
          <circle cx="152" cy="52" r="5" fill="#2D3142" /><circle cx="158" cy="74" r="4" fill="#2D3142" />
          <path d="M148 88 Q156 94 164 88" stroke="#2D3142" strokeWidth="4" fill="none" strokeLinecap="round" />
          <circle cx="140" cy="80" r="6" fill="#FFC93C" opacity=".8" />
          <path d="M40 30 l4 10 10 4 -10 4 -4 10 -4 -10 -10 -4 10 -4 Z" fill="#9B7EDE" />
          <path d="M160 110 l3 8 8 3 -8 3 -3 8 -3 -8 -8 -3 8 -3 Z" fill="#FF6B6B" />
        </svg>
      );
    case "mangga":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M100 20 Q110 6 126 8 Q114 20 100 20" fill="#2EC4B6" />
          <rect x="96" y="16" width="8" height="16" rx="4" fill="#7A4A2B" />
          <path d="M100 32 Q140 36 142 84 Q140 128 100 132 Q60 128 58 84 Q60 36 100 32 Z" fill="#FFC93C" />
          <path d="M100 32 Q140 36 142 84 Q120 70 100 72 Q80 70 58 84 Q60 36 100 32 Z" fill="#FF9F45" opacity=".85" />
          <circle cx="84" cy="92" r="5" fill="#2D3142" /><circle cx="116" cy="92" r="5" fill="#2D3142" />
          <path d="M92 106 Q100 112 108 106" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "mais":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <path d="M100 18 Q84 52 88 96 L112 96 Q116 52 100 18 Z" fill="#FFC93C" stroke="#E0A800" strokeWidth="4" />
          <g fill="#FFE66D" stroke="#E0A800" strokeWidth="2">
            <circle cx="100" cy="44" r="9" /><circle cx="100" cy="64" r="9" /><circle cx="100" cy="84" r="9" />
          </g>
          <path d="M88 70 Q60 60 52 84 Q66 96 88 92 Z" fill="#2EC4B6" />
          <path d="M112 70 Q140 60 148 84 Q134 96 112 92 Z" fill="#2EC4B6" />
          <circle cx="96" cy="58" r="3" fill="#2D3142" /><circle cx="104" cy="58" r="3" fill="#2D3142" />
        </svg>
      );
    case "manok":
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <ellipse cx="100" cy="96" rx="50" ry="42" fill="#fff" stroke="#E8E0D0" strokeWidth="4" />
          <circle cx="100" cy="52" r="30" fill="#fff" stroke="#E8E0D0" strokeWidth="4" />
          <path d="M84 28 Q84 12 96 16 Q100 6 108 16 Q120 12 116 28 Q100 36 84 28" fill="#FF6B6B" />
          <path d="M100 82 L88 96 L112 96 Z" fill="#FFC93C" />
          <circle cx="90" cy="50" r="6" fill="#2D3142" /><circle cx="110" cy="50" r="6" fill="#2D3142" />
          <circle cx="92" cy="48" r="2" fill="#fff" /><circle cx="112" cy="48" r="2" fill="#fff" />
          <path d="M92 64 Q100 70 108 64" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M52 84 Q30 70 36 48 Q54 56 60 76 Z" fill="#2EC4B6" />
          <path d="M148 84 Q170 70 164 48 Q146 56 140 76 Z" fill="#2EC4B6" />
        </svg>
      );
    default:
      return (
        <svg className={className} viewBox="0 0 200 160" role="img" aria-hidden="true">
          <circle cx="100" cy="80" r="52" fill="#FFC93C" />
          <text x="100" y="92" textAnchor="middle" fontSize="28" fontWeight="800" fill="#2D3142" fontFamily="Baloo 2, sans-serif">{art}</text>
        </svg>
      );
  }
}

export function CompanionArt({ accessory = "none", className = "" }: { accessory?: string; className?: string }) {
  return (
    <svg className={className} viewBox="0 0 220 190" role="img" aria-label="Kiko the baby carabao">
      {/* cape behind */}
      {accessory === "cape" && <path d="M60 90 Q30 150 60 176 Q90 150 84 96 Z" fill="#FF6B6B" />}
      {accessory === "star" && <path d="M60 90 Q30 150 60 176 Q90 150 84 96 Z" fill="#9B7EDE" />}
      {/* body */}
      <ellipse cx="110" cy="128" rx="62" ry="44" fill="#8D99AE" />
      <ellipse cx="110" cy="142" rx="34" ry="20" fill="#C9D1DB" />
      {/* horns */}
      <path d="M58 72 Q28 52 38 28 Q64 38 74 60 Z" fill="#E8E0D0" stroke="#B8A88A" strokeWidth="4" />
      <path d="M162 72 Q192 52 182 28 Q156 38 146 60 Z" fill="#E8E0D0" stroke="#B8A88A" strokeWidth="4" />
      {/* head */}
      <ellipse cx="110" cy="100" rx="58" ry="50" fill="#8D99AE" />
      <ellipse cx="110" cy="118" rx="36" ry="26" fill="#C9D1DB" />
      <circle cx="88" cy="92" r="9" fill="#2D3142" /><circle cx="132" cy="92" r="9" fill="#2D3142" />
      <circle cx="91" cy="89" r="3" fill="#fff" /><circle cx="135" cy="89" r="3" fill="#fff" />
      <ellipse cx="110" cy="112" rx="11" ry="7" fill="#2D3142" />
      <path d="M110 119 Q110 127 101 127 M110 119 Q110 127 119 127" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
      <circle cx="76" cy="106" r="7" fill="#FFB3B3" opacity=".85" /><circle cx="144" cy="106" r="7" fill="#FFB3B3" opacity=".85" />
      {/* ears */}
      <ellipse cx="56" cy="96" rx="12" ry="8" fill="#6C7A93" transform="rotate(-20 56 96)" />
      <ellipse cx="164" cy="96" rx="12" ry="8" fill="#6C7A93" transform="rotate(20 164 96)" />
      {/* accessories */}
      {accessory === "flower" && (
        <g>
          <circle cx="150" cy="48" r="10" fill="#FF6B6B" /><circle cx="162" cy="56" r="10" fill="#FF6B6B" /><circle cx="158" cy="70" r="10" fill="#FF6B6B" /><circle cx="144" cy="68" r="10" fill="#FF6B6B" />
          <circle cx="153" cy="60" r="8" fill="#FFC93C" />
        </g>
      )}
      {accessory === "hat" && (
        <g>
          <ellipse cx="110" cy="44" rx="52" ry="12" fill="#C68B59" />
          <path d="M82 44 Q82 18 110 18 Q138 18 138 44 Z" fill="#E8C39E" stroke="#C68B59" strokeWidth="4" />
          <rect x="82" y="34" width="56" height="10" fill="#FF6B6B" />
        </g>
      )}
      {accessory === "cape" && <circle cx="110" cy="118" r="10" fill="#FFC93C" stroke="#FF9F45" strokeWidth="3" />}
      {accessory === "star" && (
        <path d="M110 8 L116 22 L131 23 L119 32 L123 47 L110 39 L97 47 L101 32 L89 23 L104 22 Z" fill="#FFC93C" stroke="#FF9F45" strokeWidth="3" strokeLinejoin="round" />
      )}
      {accessory === "crown" && (
        <g>
          <path d="M78 42 L78 18 L94 32 L110 12 L126 32 L142 18 L142 42 Z" fill="#FFC93C" stroke="#FF9F45" strokeWidth="4" strokeLinejoin="round" />
          <circle cx="110" cy="32" r="5" fill="#FF6B6B" />
        </g>
      )}
    </svg>
  );
}

export function AvatarArt({ kind, className = "" }: { kind: string; className?: string }) {
  if (kind === "tarsier") {
    return (
      <svg className={className} viewBox="0 0 120 120" role="img" aria-hidden="true">
        <circle cx="60" cy="62" r="42" fill="#C68B59" />
        <circle cx="44" cy="52" r="16" fill="#fff" /><circle cx="76" cy="52" r="16" fill="#fff" />
        <circle cx="44" cy="52" r="9" fill="#2D3142" /><circle cx="76" cy="52" r="9" fill="#2D3142" />
        <circle cx="47" cy="49" r="3" fill="#fff" /><circle cx="79" cy="49" r="3" fill="#fff" />
        <ellipse cx="60" cy="76" rx="10" ry="6" fill="#2D3142" />
        <path d="M60 82 Q60 88 54 88 M60 82 Q60 88 66 88" stroke="#2D3142" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        <circle cx="30" cy="72" r="6" fill="#FFB3B3" /><circle cx="90" cy="72" r="6" fill="#FFB3B3" />
      </svg>
    );
  }
  if (kind === "carabao") {
    return (
      <svg className={className} viewBox="0 0 120 120" role="img" aria-hidden="true">
        <path d="M28 44 Q10 32 16 16 Q34 22 40 36 Z" fill="#E8E0D0" stroke="#B8A88A" strokeWidth="3" />
        <path d="M92 44 Q110 32 104 16 Q86 22 80 36 Z" fill="#E8E0D0" stroke="#B8A88A" strokeWidth="3" />
        <ellipse cx="60" cy="66" rx="40" ry="36" fill="#8D99AE" />
        <ellipse cx="60" cy="80" rx="24" ry="17" fill="#C9D1DB" />
        <circle cx="46" cy="60" r="6" fill="#2D3142" /><circle cx="74" cy="60" r="6" fill="#2D3142" />
        <ellipse cx="60" cy="76" rx="8" ry="5" fill="#2D3142" />
      </svg>
    );
  }
  // default sun
  return (
    <svg className={className} viewBox="0 0 120 120" role="img" aria-hidden="true">
      <circle cx="60" cy="60" r="34" fill="#FFC93C" stroke="#FF9F45" strokeWidth="4" />
      <circle cx="48" cy="54" r="4" fill="#2D3142" /><circle cx="72" cy="54" r="4" fill="#2D3142" />
      <path d="M50 68 Q60 76 70 68" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
    </svg>
  );
}

export function StickerArt({ id, color, className = "" }: { id: string; color: string; className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" role="img" aria-hidden="true">
      <circle cx="50" cy="50" r="46" fill={color} stroke="#fff" strokeWidth="5" />
      <circle cx="50" cy="50" r="46" fill="none" stroke="#2D3142" strokeWidth="2" strokeDasharray="4 6" opacity=".25" />
      <text x="50" y="60" textAnchor="middle" fontSize="30" fontWeight="800" fill="#2D3142" fontFamily="Baloo 2, sans-serif">
        {id.slice(0, 1).toUpperCase()}
      </text>
      <path d="M38 62 Q50 72 62 62" stroke="#2D3142" strokeWidth="3" fill="none" strokeLinecap="round" />
    </svg>
  );
}
