// Web Audio tones + speechSynthesis word modeling.
// Graceful fallback: if unavailable, silently no-ops (visual bubble still shows).

let ctx: AudioContext | null = null;
let muted = false;

export function setMuted(m: boolean) { muted = m; }
export function isMuted() { return muted; }

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function tone(freq: number, dur = 0.18, type: OscillatorType = "sine", delay = 0, vol = 0.18) {
  if (muted) return;
  const ac = getCtx();
  if (!ac) return;
  try {
    const t0 = ac.currentTime + delay;
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain).connect(ac.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  } catch { /* ignore */ }
}

export const sfx = {
  click() { tone(660, 0.08, "sine", 0, 0.12); },
  pop() { tone(520, 0.1, "triangle", 0, 0.16); tone(780, 0.12, "triangle", 0.06, 0.14); },
  listen() { tone(440, 0.12, "sine", 0, 0.12); tone(554, 0.12, "sine", 0.1, 0.12); },
  recordStart() { tone(392, 0.15, "sine", 0, 0.14); },
  good() { tone(523, 0.14, "triangle", 0, 0.16); tone(659, 0.14, "triangle", 0.09, 0.16); tone(784, 0.22, "triangle", 0.18, 0.16); },
  great() { tone(523, 0.12, "triangle", 0, 0.16); tone(659, 0.12, "triangle", 0.08, 0.16); tone(784, 0.12, "triangle", 0.16, 0.16); tone(1047, 0.3, "triangle", 0.24, 0.18); },
  // Gentle, never negative — soft two notes, no buzzers
  tryAgain() { tone(392, 0.16, "sine", 0, 0.12); tone(440, 0.2, "sine", 0.14, 0.12); },
  reward() { [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(f, 0.18, "triangle", i * 0.1, 0.15)); },
  step() { tone(587, 0.12, "sine", 0, 0.14); },
};

export function speakWord(word: string, lang: "en" | "fil"): boolean {
  if (muted) return false;
  try {
    if (!("speechSynthesis" in window)) return false;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(word);
    u.lang = lang === "fil" ? "fil-PH" : "en-US";
    u.rate = 0.82;
    u.pitch = 1.15;
    // Prefer a Filipino voice if available
    const voices = window.speechSynthesis.getVoices();
    const filVoice = voices.find((v) => v.lang.toLowerCase().startsWith("fil"));
    const enVoice = voices.find((v) => v.lang.toLowerCase().startsWith("en"));
    if (lang === "fil" && filVoice) u.voice = filVoice;
    else if (lang === "en" && enVoice) u.voice = enVoice;
    window.speechSynthesis.speak(u);
    return true;
  } catch {
    return false;
  }
}
