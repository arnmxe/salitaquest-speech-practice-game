import { useEffect, useMemo, useRef, useState } from "react";
import { GAME_DATA, REPS_PER_LEVEL, DAILY_GOAL_SECONDS, STR, type Lang } from "./data";
import { sfx, speakWord, setMuted as setAudioMuted } from "./audio";
import { WordArt, CompanionArt, AvatarArt, StickerArt } from "./components/Art";

// ── Icons (inline SVG, no emoji) ─────────────────────────────
const I = {
  star: (c = "w-5 h-5") => (
    <svg className={c} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.2 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8L12 2z" /></svg>
  ),
  flame: (c = "w-5 h-5") => (
    <svg className={c} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2c1 4-3 5.5-3 9a3 3 0 0 0 6 0c0-1-.5-2-.5-2s3 1.5 3 5a5.5 5.5 0 0 1-11 0C6.5 8 12 6 12 2z" /></svg>
  ),
  mic: (c = "w-8 h-8") => (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3" fill="currentColor" stroke="none" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></svg>
  ),
  speaker: (c = "w-6 h-6") => (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M11 5L6 9H3v6h3l5 4V5z" fill="currentColor" stroke="none" /><path d="M15.5 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12" /></svg>
  ),
  check: (c = "w-5 h-5") => (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M4 12.5l5 5L20 6.5" /></svg>
  ),
  back: (c = "w-6 h-6") => (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7" /></svg>
  ),
  lock: (c = "w-5 h-5") => (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2.5" fill="currentColor" stroke="none" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></svg>
  ),
  soundOn: (c = "w-6 h-6") => (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true"><path d="M11 5L6 9H3v6h3l5 4V5z" fill="currentColor" stroke="none" /><path d="M15.5 8.5a5 5 0 0 1 0 7" /></svg>
  ),
  soundOff: (c = "w-6 h-6") => (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true"><path d="M11 5L6 9H3v6h3l5 4V5z" fill="currentColor" stroke="none" /><path d="M16 9l6 6M22 9l-6 6" /></svg>
  ),
  heart: (c = "w-5 h-5") => (
    <svg className={c} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21s-7.5-4.6-10-9C.4 8.6 2.3 5 5.7 5c2 0 3.4 1.1 4.3 2.4h4C15 6.1 16.4 5 18.4 5c3.4 0 5.3 3.6 3.6 7-2.5 4.4-10 9-10 9z" transform="scale(.9) translate(1.3 1)" /></svg>
  ),
};

type Screen = "splash" | "profiles" | "onboarding" | "map" | "level" | "reward" | "companion" | "assigned" | "parentGate" | "parent" | "summary";
type Phase = "listen" | "record" | "rating";

function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [lang, setLang] = useState<Lang>("en");
  const [muted, setMutedState] = useState(false);
  const t = STR[lang];

  const [profile, setProfile] = useState({ nickname: "Mika", avatar: "tarsier" });
  const [nicknameInput, setNicknameInput] = useState("");
  const [onboardStep, setOnboardStep] = useState(0);
  const [hasOnboarded, setHasOnboarded] = useState(false);

  const [currentWorldId, setCurrentWorldId] = useState("beach");
  const [currentWordId, setCurrentWordId] = useState("araw");
  const [repsDone, setRepsDone] = useState(0);
  const [phase, setPhase] = useState<Phase>("listen");
  const [feedback, setFeedback] = useState<string | null>(null);
  const [bubbleWord, setBubbleWord] = useState<string | null>(null);

  const [completed, setCompleted] = useState<Record<string, number>>({}); // wordId -> stars earned best
  const [starsTotal, setStarsTotal] = useState(0);
  const [stickers, setStickers] = useState<string[]>([]);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [ratingsCount, setRatingsCount] = useState(0);
  const [attempts, setAttempts] = useState(0);
  void attempts;
  const [wordsPracticed, setWordsPracticed] = useState<Set<string>>(new Set());

  const [micGranted, setMicGranted] = useState<boolean | null>(null);
  const [showMicModal, setShowMicModal] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [lastSticker, setLastSticker] = useState<string | null>(null);
  const [lastStars, setLastStars] = useState(0);

  // Parent gate
  const [gateA, setGateA] = useState(4);
  const [gateB, setGateB] = useState(3);
  const [gateInput, setGateInput] = useState("");
  const [gateError, setGateError] = useState(false);
  const [gateReturn, setGateReturn] = useState<Screen>("parent");

  const recTimer = useRef<number | null>(null);
  const fbTimer = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Session timer (in-memory only)
  useEffect(() => {
    const id = window.setInterval(() => setSessionSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => { setAudioMuted(muted); }, [muted]);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(id);
  }, [toast]);

  useEffect(() => () => {
    if (recTimer.current) window.clearTimeout(recTimer.current);
    if (fbTimer.current) window.clearTimeout(fbTimer.current);
    streamRef.current?.getTracks().forEach((tr) => tr.stop());
  }, []);

  const world = useMemo(() => GAME_DATA.worlds.find((w) => w.id === currentWorldId) ?? GAME_DATA.worlds[0], [currentWorldId]);
  const wordItem = useMemo(() => {
    for (const w of GAME_DATA.worlds) {
      const f = w.words.find((x) => x.id === currentWordId);
      if (f) return f;
    }
    return GAME_DATA.worlds[0].words[0];
  }, [currentWordId]);

  const completedCount = Object.keys(completed).length;
  const companionStage = useMemo(() => {
    let cur = GAME_DATA.companionStages[0];
    for (const s of GAME_DATA.companionStages) if (completedCount >= s.minLevels) cur = s;
    return cur;
  }, [completedCount]);
  const nextStage = GAME_DATA.companionStages.find((s) => s.minLevels > completedCount);

  const dailyPct = Math.min(100, Math.round((sessionSeconds / DAILY_GOAL_SECONDS) * 100));
  const streakDays = 4; // mock streak; +1 today when goal met

  function showToast(msg: string) { setToast(msg); }

  function openWord(worldId: string, wordId: string) {
    sfx.pop();
    setCurrentWorldId(worldId);
    setCurrentWordId(wordId);
    setRepsDone(0);
    setPhase("listen");
    setFeedback(null);
    setBubbleWord(null);
    setScreen("level");
  }

  function handleListen() {
    sfx.listen();
    const ok = speakWord(wordItem.word, lang);
    setBubbleWord(wordItem.word);
    if (!ok) showToast(lang === "fil" ? "Makinig: " + wordItem.word : "Listen: " + wordItem.word);
    window.setTimeout(() => setBubbleWord(null), 2200);
  }

  async function requestMic() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      // Discard immediately — never upload or save
      stream.getTracks().forEach((tr) => tr.stop());
      streamRef.current = null;
      setMicGranted(true);
    } catch {
      setMicGranted(false);
      showToast(t.micDenied);
    }
  }

  function handleMic() {
    if (micGranted === null) { setShowMicModal(true); return; }
    startRecording();
  }

  function startRecording() {
    sfx.recordStart();
    setPhase("record");
    setFeedback(null);
    if (recTimer.current) window.clearTimeout(recTimer.current);
    recTimer.current = window.setTimeout(() => {
      setPhase("rating");
      sfx.pop();
    }, 2600);
  }

  function handleRating(r: 1 | 2 | 3) {
    setRatingsCount((c) => c + 1);
    setAttempts((c) => c + 1);
    setWordsPracticed((prev) => new Set(prev).add(wordItem.id));
    if (r === 1) {
      sfx.tryAgain();
      setFeedback(t.letsTryAgain);
      setPhase("listen");
      if (fbTimer.current) window.clearTimeout(fbTimer.current);
      fbTimer.current = window.setTimeout(() => setFeedback(null), 2400);
      // Auto-model again gently
      window.setTimeout(() => speakWord(wordItem.word, lang), 500);
      return;
    }
    if (r === 2) sfx.good(); else sfx.great();
    const newReps = repsDone + 1;
    setRepsDone(newReps);
    setStarsTotal((s) => s + r);
    setFeedback(r === 2 ? t.goodJob : t.greatJob);
    if (newReps >= REPS_PER_LEVEL) {
      // Level complete → reward
      const newCompleted = { ...completed, [wordItem.id]: Math.max(completed[wordItem.id] ?? 0, r) };
      setCompleted(newCompleted);
      const idx = Object.keys(newCompleted).length - 1;
      const stickerId = GAME_DATA.stickers[idx % GAME_DATA.stickers.length].id;
      setStickers((prev) => (prev.includes(stickerId) ? prev : [...prev, stickerId]));
      setLastSticker(stickerId);
      setLastStars(r);
      window.setTimeout(() => {
        sfx.reward();
        setScreen("reward");
      }, 1100);
    } else {
      setPhase("listen");
      sfx.step();
      if (fbTimer.current) window.clearTimeout(fbTimer.current);
      fbTimer.current = window.setTimeout(() => setFeedback(null), 2000);
    }
  }

  function nextWordAfterReward() {
    // Find next incomplete word in same world, else next world, else map
    const wIdx = GAME_DATA.worlds.findIndex((w) => w.id === currentWorldId);
    const w = GAME_DATA.worlds[wIdx];
    const nextInWorld = w.words.find((x) => !completed[x.id]);
    if (nextInWorld) { openWord(w.id, nextInWorld.id); return; }
    for (let i = 1; i <= GAME_DATA.worlds.length; i++) {
      const nw = GAME_DATA.worlds[(wIdx + i) % GAME_DATA.worlds.length];
      const cand = nw.words.find((x) => !completed[x.id]);
      if (cand) { openWord(nw.id, cand.id); return; }
    }
    setScreen("map");
  }

  function openParentGate(returnTo: Screen = "parent") {
    sfx.click();
    setGateA(2 + Math.floor(Math.random() * 7));
    setGateB(2 + Math.floor(Math.random() * 7));
    setGateInput("");
    setGateError(false);
    setGateReturn(returnTo);
    setScreen("parentGate");
  }

  function checkGate() {
    if (Number(gateInput) === gateA + gateB) {
      sfx.good();
      setScreen(gateReturn);
    } else {
      sfx.tryAgain();
      setGateError(true);
    }
  }

  function resetProgress() {
    setCompleted({});
    setStarsTotal(0);
    setStickers([]);
    setRatingsCount(0);
    setAttempts(0);
    setWordsPracticed(new Set());
    setSessionSeconds(0);
    setSent(false);
    showToast(t.resetDone);
    sfx.pop();
  }

  function sendToTherapist() {
    sfx.reward();
    setSent(true);
    showToast(t.sent);
  }

  // ── Shared UI bits ─────────────────────────────────────────
  const TopBar = ({ title, onBack }: { title: string; onBack?: () => void }) => (
    <header className="sticky top-0 z-30 bg-[#FFFBEB]/90 backdrop-blur border-b border-amber-100">
      <div className="mx-auto max-w-3xl px-3 py-2 flex items-center gap-2">
        {onBack && (
          <button onClick={onBack} aria-label="Back" className="tap w-14 h-14 rounded-full bg-white border-2 border-amber-200 flex items-center justify-center text-[#2D3142] active:scale-95 transition">
            {I.back()}
          </button>
        )}
        <div className="flex-1 min-w-0">
          <p className="font-display font-bold text-lg leading-tight truncate">{title}</p>
          <p className="text-xs font-bold text-slate-500 truncate">{profile.nickname} • {fmtTime(sessionSeconds)}</p>
        </div>
        <div className="flex items-center gap-1.5 bg-white border-2 border-amber-200 rounded-full px-3 h-11 font-display font-bold text-[#B7791F]">
          <span className="text-[#FFC93C]">{I.star("w-5 h-5")}</span>{starsTotal}
        </div>
        <button onClick={() => setMutedState((m) => !m)} aria-label={muted ? "Unmute" : "Mute"} className="tap w-14 h-14 rounded-full bg-white border-2 border-amber-200 flex items-center justify-center active:scale-95 transition">
          {muted ? I.soundOff() : I.soundOn()}
        </button>
      </div>
    </header>
  );

  const BottomNav = ({ active }: { active: string }) => (
    <nav className="fixed bottom-0 inset-x-0 z-30 bg-white/95 backdrop-blur border-t-2 border-amber-100 pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto max-w-3xl grid grid-cols-4 px-2 py-2 gap-1">
        {[
          { id: "map", label: lang === "fil" ? "Mapa" : "Map", icon: <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14" /></svg> },
          { id: "assigned", label: t.assignedList, icon: <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><rect x="5" y="4" width="14" height="17" rx="3" /><path d="M9 4a3 3 0 0 1 6 0M9 12l2 2 4-4" /></svg> },
          { id: "companion", label: "Kiko", icon: <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7-4.3-9.3-8.5C1 9 3 5.5 6.5 5.5c2 0 3.3 1 4.2 2.3h2.6C14.2 6.5 15.5 5.5 17.5 5.5 21 5.5 23 9 21.3 12.5 19 16.7 12 21 12 21z" /></svg> },
          { id: "parent", label: lang === "fil" ? "Magulang" : "Parent", icon: I.lock("w-6 h-6") },
        ].map((b) => (
          <button
            key={b.id}
            onClick={() => {
              sfx.click();
              if (b.id === "parent") openParentGate("parent");
              else setScreen(b.id as Screen);
            }}
            className={`tap min-h-[56px] rounded-2xl flex flex-col items-center justify-center gap-0.5 font-display font-bold text-xs ${active === b.id ? "bg-[#2EC4B6] text-white" : "text-slate-600 bg-transparent"}`}
            aria-current={active === b.id ? "page" : undefined}
          >
            {b.icon}<span className="leading-none">{b.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );

  const LangToggle = () => (
    <div className="inline-flex bg-white border-2 border-amber-200 rounded-full p-1" role="group" aria-label="Language">
      {(["en", "fil"] as Lang[]).map((l) => (
        <button key={l} onClick={() => { setLang(l); sfx.click(); }} className={`tap min-h-[44px] px-4 rounded-full font-display font-bold text-sm ${lang === l ? "bg-[#2D3142] text-white" : "text-slate-600"}`}>
          {l === "en" ? "EN" : "FIL"}
        </button>
      ))}
    </div>
  );

  // ── Screens ────────────────────────────────────────────────
  if (screen === "splash") {
    return (
      <div className="min-h-dvh bg-[#FFFBEB] flex flex-col overflow-x-hidden">
        <div className="mx-auto w-full max-w-3xl px-4 pt-4 flex items-center justify-between">
          <LangToggle />
          <button onClick={() => openParentGate("parent")} className="tap min-h-[44px] px-4 rounded-full bg-white border-2 border-amber-200 font-display font-bold text-sm flex items-center gap-2">
            {I.lock("w-4 h-4")} {t.parentArea}
          </button>
        </div>
        <main className="flex-1 flex flex-col items-center justify-center px-4 py-8 text-center">
          <div className="anim-floaty w-40 h-40 sm:w-52 sm:h-52">
            <CompanionArt accessory="flower" className="w-full h-full drop-shadow-xl" />
          </div>
          <h1 className="font-display font-extrabold text-5xl sm:text-6xl tracking-tight mt-2">
            <span className="text-[#2EC4B6]">Salita</span><span className="text-[#FF6B6B]">Quest</span>
          </h1>
          <p className="mt-2 text-lg font-bold text-slate-600 max-w-md">{t.tagline}</p>
          <p className="mt-1 text-sm font-semibold text-slate-500">{t.therapistNote} • {GAME_DATA.therapist.name}</p>
          <button onClick={() => { sfx.pop(); setScreen("profiles"); }} className="tap mt-8 min-h-[64px] px-10 rounded-full bg-[#FF6B6B] text-white font-display font-extrabold text-2xl shadow-[0_8px_0_#D94F4F] active:translate-y-1 active:shadow-none transition flex items-center gap-3">
            <svg className="w-7 h-7" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z" /></svg>
            {t.play}
          </button>
          <p className="mt-4 text-xs font-bold text-slate-400 max-w-xs">{t.noFailNote}</p>
        </main>
        <footer className="pb-6 text-center text-xs font-bold text-slate-400 px-4">Ages 4–8 • {t.privacy} • RA 10173</footer>
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  if (screen === "profiles") {
    const presets = [
      { nickname: "Mika", avatar: "tarsier" },
      { nickname: "Rico", avatar: "carabao" },
    ];
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden">
        <TopBar title={t.chooseExplorer} onBack={() => setScreen("splash")} />
        <main className="mx-auto max-w-3xl px-4 py-6 pb-28">
          <div className="grid sm:grid-cols-2 gap-4">
            {presets.map((p) => (
              <button key={p.nickname} onClick={() => { sfx.pop(); setProfile(p); setScreen(hasOnboarded ? "map" : "onboarding"); }} className="tap min-h-[120px] bg-white rounded-[28px] border-4 border-amber-200 p-5 flex items-center gap-4 text-left active:scale-[.98] transition shadow-sm">
                <div className="w-20 h-20 shrink-0 bg-[#FFF3C4] rounded-3xl p-2"><AvatarArt kind={p.avatar} className="w-full h-full" /></div>
                <div>
                  <p className="font-display font-extrabold text-2xl">{p.nickname}</p>
                  <p className="text-sm font-bold text-slate-500">{t.tapToStart}</p>
                </div>
              </button>
            ))}
          </div>
          <div className="mt-6 bg-white rounded-[28px] border-4 border-[#D9F5F1] p-5">
            <p className="font-display font-bold text-lg mb-3">{t.newExplorer}</p>
            <div className="flex gap-2 mb-3">
              {["tarsier", "carabao", "sun"].map((a) => (
                <button key={a} onClick={() => { setProfile((pr) => ({ ...pr, avatar: a })); sfx.click(); }} aria-label={`Avatar ${a}`} className={`tap w-16 h-16 rounded-2xl border-4 p-1.5 ${profile.avatar === a ? "border-[#2EC4B6] bg-[#D9F5F1]" : "border-slate-200 bg-slate-50"}`}>
                  <AvatarArt kind={a} className="w-full h-full" />
                </button>
              ))}
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <input value={nicknameInput} onChange={(e) => setNicknameInput(e.target.value.slice(0, 12))} placeholder={t.typeNickname} className="tap flex-1 min-h-[56px] rounded-2xl border-2 border-slate-200 px-4 font-bold text-lg bg-[#FFFBEB]" aria-label={t.typeNickname} />
              <button onClick={() => { const n = nicknameInput.trim() || "Explorer"; sfx.pop(); setProfile({ nickname: n, avatar: profile.avatar }); setScreen(hasOnboarded ? "map" : "onboarding"); }} className="tap min-h-[56px] px-6 rounded-2xl bg-[#2EC4B6] text-white font-display font-extrabold text-lg active:scale-95 transition">
                {t.start}
              </button>
            </div>
            <p className="mt-3 text-xs font-bold text-slate-400">{lang === "fil" ? "Gumamit ng palayaw lamang — hindi buong pangalan." : "Use a nickname only — never a full name."}</p>
          </div>
        </main>
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  if (screen === "onboarding") {
    const steps = [
      { title: t.onboarding1Title, text: t.onboarding1Text, art: "araw", color: "#FFC93C" },
      { title: t.onboarding2Title, text: t.onboarding2Text, art: "lobo", color: "#2EC4B6" },
      { title: t.onboarding3Title, text: t.onboarding3Text, art: "bituin", color: "#9B7EDE" },
    ];
    const s = steps[onboardStep];
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden flex flex-col">
        <TopBar title={`${t.hello}, ${profile.nickname}!`} onBack={() => setScreen("profiles")} />
        <main className="flex-1 mx-auto w-full max-w-3xl px-4 py-6 flex flex-col items-center justify-center text-center">
          <div className="flex gap-2 mb-6" aria-hidden="true">
            {steps.map((_, i) => <span key={i} className={`h-3 rounded-full transition-all ${i === onboardStep ? "w-10 bg-[#FF6B6B]" : "w-3 bg-slate-300"}`} />)}
          </div>
          <div className="anim-pop bg-white rounded-[32px] border-4 p-6 w-full max-w-md shadow-sm" style={{ borderColor: s.color }}>
            <div className="w-44 h-36 mx-auto"><WordArt art={s.art} className="w-full h-full" /></div>
            <h2 className="font-display font-extrabold text-3xl mt-3">{s.title}</h2>
            <p className="mt-2 font-bold text-slate-600 text-lg leading-snug">{s.text}</p>
            {onboardStep === 1 && (
              <div className="mt-4 mx-auto w-20 h-20 rounded-full bg-[#FF6B6B] text-white flex items-center justify-center anim-pulse-ring">{I.mic("w-10 h-10")}</div>
            )}
            {onboardStep === 2 && (
              <div className="mt-4 flex justify-center gap-2 text-[#FFC93C]">
                {I.star("w-10 h-10")}{I.star("w-10 h-10")}{I.star("w-10 h-10")}
              </div>
            )}
          </div>
          <div className="mt-6 flex flex-col sm:flex-row gap-3 w-full max-w-md">
            <button onClick={() => { sfx.click(); setHasOnboarded(true); setScreen("map"); }} className="tap flex-1 min-h-[56px] rounded-full bg-white border-2 border-slate-200 font-display font-bold text-lg">{t.skip}</button>
            {onboardStep < 2 ? (
              <button onClick={() => { sfx.pop(); setOnboardStep((v) => v + 1); }} className="tap flex-1 min-h-[64px] rounded-full bg-[#2EC4B6] text-white font-display font-extrabold text-xl active:scale-95 transition">{t.next}</button>
            ) : (
              <button onClick={() => { sfx.pop(); setHasOnboarded(true); setScreen("map"); }} className="tap flex-1 min-h-[64px] rounded-full bg-[#FF6B6B] text-white font-display font-extrabold text-xl active:scale-95 transition">{t.gotIt}</button>
            )}
          </div>
        </main>
      </div>
    );
  }

  if (screen === "map") {
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden">
        <TopBar title={t.worlds} />
        <main className="mx-auto max-w-3xl px-4 pt-4 pb-32">
          {/* Daily goal + streak */}
          <section className="bg-white rounded-[28px] border-4 border-amber-200 p-4 mb-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-[#FFE0E0] text-[#FF6B6B] flex items-center justify-center shrink-0">{I.flame("w-8 h-8")}</div>
              <div className="flex-1 min-w-0">
                <p className="font-display font-extrabold text-lg leading-tight">{t.practiceToday}</p>
                <p className="text-sm font-bold text-slate-500">{streakDays} {t.dayStreak} • {fmtTime(sessionSeconds)} / 5:00</p>
              </div>
              <span className="font-display font-extrabold text-2xl text-[#FF6B6B]">{dailyPct}%</span>
            </div>
            <div className="mt-3 h-5 rounded-full bg-slate-100 overflow-hidden" role="progressbar" aria-valuenow={dailyPct} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full bg-gradient-to-r from-[#FFC93C] to-[#FF6B6B] rounded-full transition-all duration-500" style={{ width: `${dailyPct}%` }} />
            </div>
            {dailyPct >= 100 && <p className="mt-2 font-display font-bold text-[#2EC4B6] flex items-center gap-1">{I.check()} {lang === "fil" ? "Naabot ang layunin ngayon!" : "Daily goal reached today!"}</p>}
          </section>

          {/* Assigned banner */}
          <button onClick={() => { sfx.click(); setScreen("assigned"); }} className="tap w-full min-h-[64px] bg-[#9B7EDE] text-white rounded-[24px] p-4 mb-5 flex items-center gap-3 text-left active:scale-[.99] transition shadow-sm">
            <span className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center shrink-0">{I.heart("w-6 h-6")}</span>
            <span className="flex-1 min-w-0">
              <span className="block font-display font-extrabold text-lg leading-tight">{t.assignedBy} {GAME_DATA.therapist.name}</span>
              <span className="block text-sm font-bold opacity-90">{GAME_DATA.therapist.targetSound} • {lang === "fil" ? GAME_DATA.therapist.focusFil : GAME_DATA.therapist.focusEn} • {t.due} {lang === "fil" ? GAME_DATA.therapist.dueDateFil : GAME_DATA.therapist.dueDateEn}</span>
            </span>
            <span className="font-display font-bold bg-white text-[#9B7EDE] rounded-full px-3 py-1 text-sm shrink-0">{GAME_DATA.assignedWordIds.filter((id) => wordsPracticed.has(id)).length}/{GAME_DATA.assignedWordIds.length}</span>
          </button>

          {/* Worlds */}
          <div className="space-y-4">
            {GAME_DATA.worlds.map((w, wi) => {
              const done = w.words.filter((x) => completed[x.id]).length;
              return (
                <section key={w.id} className="bg-white rounded-[28px] border-4 p-4 shadow-sm" style={{ borderColor: w.color }}>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="w-12 h-12 rounded-2xl flex items-center justify-center font-display font-extrabold text-white text-xl shrink-0" style={{ background: w.color }}>{wi + 1}</span>
                    <div className="flex-1 min-w-0">
                      <h2 className="font-display font-extrabold text-2xl leading-none">{lang === "fil" ? w.nameFil : w.nameEn}</h2>
                      <p className="text-sm font-bold text-slate-500">{w.targetSound} • {lang === "fil" ? w.targetLabelFil : w.targetLabelEn} • {done}/{w.words.length}</p>
                    </div>
                    <span className="text-xs font-display font-bold px-3 py-1.5 rounded-full" style={{ background: w.soft }}>{done === w.words.length ? "★" : `${done * 2} ${t.stars}`}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {w.words.map((wd) => {
                      const isDone = !!completed[wd.id];
                      const isAssigned = GAME_DATA.assignedWordIds.includes(wd.id);
                      return (
                        <button key={wd.id} onClick={() => openWord(w.id, wd.id)} className={`tap min-h-[110px] rounded-3xl border-3 p-2 flex flex-col items-center justify-center gap-1 active:scale-95 transition ${isDone ? "bg-[#D9F5F1] border-[#2EC4B6]" : "bg-[#FFFBEB] border-slate-200"}`} style={{ borderWidth: 3 }}>
                          <div className="w-16 h-12"><WordArt art={wd.art} className="w-full h-full" /></div>
                          <span className="font-display font-extrabold text-lg leading-none">{wd.word}</span>
                          <span className="text-[11px] font-bold text-slate-500 leading-none">{wd.syllables}</span>
                          {isDone ? <span className="text-[#2EC4B6]">{I.check("w-5 h-5")}</span> : isAssigned ? <span className="text-[10px] font-display font-bold bg-[#9B7EDE] text-white px-2 py-0.5 rounded-full">★ {GAME_DATA.therapist.name.split(" ")[1]}</span> : <span className="text-[10px] font-bold text-slate-400">{wd.en}</span>}
                        </button>
                      );
                    })}
                  </div>
                </section>
              );
            })}
          </div>

          <button onClick={() => { sfx.click(); setScreen("summary"); }} className="tap mt-6 w-full min-h-[64px] rounded-full bg-[#2D3142] text-white font-display font-extrabold text-xl active:scale-[.99] transition">
            {t.finish}
          </button>
        </main>
        <BottomNav active="map" />
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  if (screen === "level") {
    const steps = Array.from({ length: REPS_PER_LEVEL }, (_, i) => i);
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden">
        <TopBar title={`${lang === "fil" ? world.nameFil : world.nameEn} • ${wordItem.word}`} onBack={() => setScreen("map")} />
        <main className="mx-auto max-w-3xl px-4 pt-3 pb-32">
          {/* Climbing steps meter */}
          <div className="bg-white rounded-[24px] border-4 border-amber-200 p-3 mb-3">
            <div className="flex items-center justify-between mb-2">
              <p className="font-display font-bold text-sm">{t.step} {Math.min(repsDone + 1, REPS_PER_LEVEL)} {t.of} {REPS_PER_LEVEL} • {repsDone}/{REPS_PER_LEVEL} {t.reps}</p>
              <span className="text-xs font-bold px-2 py-1 rounded-full" style={{ background: world.soft }}>{world.targetSound}</span>
            </div>
            <div className="relative h-20 bg-gradient-to-t from-[#FFF3C4] to-white rounded-2xl overflow-hidden flex items-end px-2 pb-2 gap-1.5" aria-label={`${repsDone} of ${REPS_PER_LEVEL}`}>
              {steps.map((i) => (
                <div key={i} className={`flex-1 rounded-t-xl transition-all duration-300 ${i < repsDone ? "bg-[#2EC4B6]" : "bg-slate-200"}`} style={{ height: `${28 + i * 16}%` }} />
              ))}
              <div className="absolute bottom-1 transition-all duration-500" style={{ left: `calc(${Math.min(repsDone, REPS_PER_LEVEL - 1) * 24}% + 8px)` }}>
                <div className="w-12 h-10"><CompanionArt accessory={companionStage.accessory} className="w-full h-full" /></div>
              </div>
            </div>
          </div>

          {/* Word card */}
          <section className="bg-white rounded-[32px] border-4 p-4 sm:p-6 shadow-sm relative" style={{ borderColor: world.color }}>
            {bubbleWord && (
              <div className="anim-bubble absolute -top-4 left-1/2 -translate-x-1/2 bg-[#2D3142] text-white font-display font-extrabold text-xl px-5 py-2 rounded-full shadow-lg z-10">
                “{bubbleWord}!”
              </div>
            )}
            <div className="w-full max-w-[280px] h-44 mx-auto"><WordArt art={wordItem.art} className="w-full h-full" /></div>
            <h2 className="text-center font-display font-extrabold text-5xl sm:text-6xl tracking-tight mt-1">{wordItem.word}</h2>
            <p className="text-center font-display font-bold text-xl text-slate-500 tracking-widest">{wordItem.syllables}</p>
            <p className="text-center text-sm font-bold text-slate-400">{lang === "fil" ? wordItem.fil : wordItem.en}</p>

            <button onClick={handleListen} className="tap mt-4 w-full min-h-[64px] rounded-full bg-[#FFC93C] text-[#2D3142] font-display font-extrabold text-2xl flex items-center justify-center gap-3 shadow-[0_6px_0_#E0A800] active:translate-y-1 active:shadow-none transition">
              {I.speaker("w-8 h-8")} {t.listen}
            </button>
            <p className="text-center text-xs font-bold text-slate-400 mt-2">{t.listenFirst}</p>
          </section>

          {feedback && (
            <div className="anim-pop mt-3 bg-[#2EC4B6] text-white font-display font-extrabold text-xl text-center rounded-full py-3 px-4" role="status">
              {feedback}
            </div>
          )}

          {/* Mic / Rating */}
          {phase === "listen" && (
            <div className="mt-4 flex flex-col items-center">
              <button onClick={handleMic} aria-label={t.tapMic} className="tap w-28 h-28 rounded-full bg-[#FF6B6B] text-white flex flex-col items-center justify-center gap-1 shadow-[0_8px_0_#D94F4F] active:translate-y-1 active:shadow-none transition">
                {I.mic("w-12 h-12")}
                <span className="font-display font-extrabold text-sm leading-none">{t.sayIt}</span>
              </button>
              <p className="mt-2 font-display font-bold text-slate-600">{t.tapMic}</p>
            </div>
          )}

          {phase === "record" && (
            <div className="mt-4 bg-white rounded-[28px] border-4 border-[#FF6B6B] p-5 text-center anim-pop">
              <p className="font-display font-extrabold text-2xl text-[#FF6B6B]">{t.listening}</p>
              <div className="mt-3 flex items-end justify-center gap-1.5 h-12" aria-hidden="true">
                {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
                  <span key={i} className="wave-bar w-2.5 rounded-full bg-[#FF6B6B]" style={{ height: `${18 + ((i * 13) % 30)}px`, animationDelay: `${i * 0.08}s` }} />
                ))}
              </div>
              <p className="mt-2 font-display font-extrabold text-3xl">“{wordItem.word}”</p>
            </div>
          )}

          {phase === "rating" && (
            <div className="mt-4 bg-white rounded-[28px] border-4 border-[#2EC4B6] p-4 anim-pop">
              <p className="text-center font-display font-extrabold text-2xl mb-3">{t.howDidItGo}</p>
              <div className="grid grid-cols-3 gap-2">
                {([
                  { r: 1 as const, label: t.tryAgain, stars: 1, bg: "bg-[#FFF3C4] border-[#FFC93C] text-[#7A5A00]", face: "M8 10h.01M16 10h.01M9 15q3-2 6 0" },
                  { r: 2 as const, label: t.good, stars: 2, bg: "bg-[#D9F5F1] border-[#2EC4B6] text-[#0F766E]", face: "M8 10h.01M16 10h.01M8 14q4 4 8 0" },
                  { r: 3 as const, label: t.great, stars: 3, bg: "bg-[#FFE0E0] border-[#FF6B6B] text-[#9F1239]", face: "M8 10h.01M16 10h.01M7 13q5 6 10 0" },
                ]).map((o) => (
                  <button key={o.r} onClick={() => handleRating(o.r)} className={`tap min-h-[110px] rounded-3xl border-4 ${o.bg} flex flex-col items-center justify-center gap-1 active:scale-95 transition`}>
                    <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="white" stroke="currentColor" /><path d={o.face} /></svg>
                    <span className="flex text-[#FFC93C]">{Array.from({ length: o.stars }).map((_, i) => <span key={i}>{I.star("w-5 h-5")}</span>)}</span>
                    <span className="font-display font-extrabold text-base leading-tight text-center px-1">{o.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </main>

        {showMicModal && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-4" role="dialog" aria-modal="true" aria-label={t.micTitle}>
            <div className="anim-pop bg-white rounded-[28px] p-6 w-full max-w-md">
              <div className="w-16 h-16 rounded-full bg-[#FFE0E0] text-[#FF6B6B] flex items-center justify-center mb-3">{I.mic("w-8 h-8")}</div>
              <h2 className="font-display font-extrabold text-2xl">{t.micTitle}</h2>
              <p className="mt-2 font-semibold text-slate-600 leading-relaxed">{t.micText}</p>
              <div className="mt-5 flex flex-col gap-2">
                <button onClick={async () => { await requestMic(); setShowMicModal(false); startRecording(); }} className="tap min-h-[60px] rounded-full bg-[#FF6B6B] text-white font-display font-extrabold text-lg active:scale-[.99] transition">{t.allowMic}</button>
                <button onClick={() => { setMicGranted(false); setShowMicModal(false); startRecording(); }} className="tap min-h-[56px] rounded-full bg-slate-100 font-display font-bold text-lg">{t.notNow}</button>
              </div>
            </div>
          </div>
        )}
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  if (screen === "reward") {
    const sticker = GAME_DATA.stickers.find((s) => s.id === lastSticker);
    const confetti = Array.from({ length: 26 }, (_, i) => ({
      left: (i * 37) % 100,
      delay: (i % 8) * 0.12,
      dur: 2.2 + (i % 5) * 0.3,
      color: ["#FFC93C", "#2EC4B6", "#FF6B6B", "#9B7EDE"][i % 4],
      w: 8 + (i % 3) * 4,
    }));
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden relative">
        <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
          {confetti.map((c, i) => (
            <span key={i} className="confetti-piece" style={{ left: `${c.left}%`, width: c.w, height: c.w * 1.6, background: c.color, animationDelay: `${c.delay}s`, animationDuration: `${c.dur}s` }} />
          ))}
        </div>
        <TopBar title={t.youEarned} onBack={() => setScreen("map")} />
        <main className="relative mx-auto max-w-3xl px-4 py-6 pb-32 text-center">
          <div className="anim-pop bg-white rounded-[32px] border-4 border-[#FFC93C] p-6 shadow-sm">
            <div className="flex justify-center gap-2 text-[#FFC93C]">
              {Array.from({ length: lastStars || 3 }).map((_, i) => <span key={i} className="anim-pop" style={{ animationDelay: `${i * 0.12}s` }}>{I.star("w-12 h-12")}</span>)}
            </div>
            <h2 className="font-display font-extrabold text-3xl mt-2">{t.greatJob}</h2>
            <p className="font-bold text-slate-500">“{wordItem.word}” • {REPS_PER_LEVEL} {t.reps}</p>

            {sticker && (
              <div className="mt-5 flex flex-col items-center">
                <p className="font-display font-bold text-lg mb-2">{t.youEarned}</p>
                <div className="w-28 h-28 anim-floaty"><StickerArt id={sticker.id} color={sticker.color} className="w-full h-full drop-shadow-lg" /></div>
                <p className="font-display font-extrabold text-xl mt-2">{lang === "fil" ? sticker.labelFil : sticker.labelEn}</p>
              </div>
            )}

            <div className="mt-5 bg-[#FFF3C4] rounded-3xl p-4">
              <div className="w-36 h-32 mx-auto"><CompanionArt accessory={companionStage.accessory} className="w-full h-full" /></div>
              <p className="font-display font-extrabold text-xl">{lang === "fil" ? companionStage.labelFil : companionStage.labelEn}</p>
              <p className="text-sm font-bold text-slate-600">{t.kikoGrew}</p>
            </div>
          </div>

          <div className="mt-5 flex flex-col sm:flex-row gap-3">
            <button onClick={nextWordAfterReward} className="tap flex-1 min-h-[64px] rounded-full bg-[#FF6B6B] text-white font-display font-extrabold text-xl shadow-[0_6px_0_#D94F4F] active:translate-y-1 active:shadow-none transition">{t.nextWord}</button>
            <button onClick={() => { sfx.click(); setScreen("companion"); }} className="tap flex-1 min-h-[64px] rounded-full bg-[#2EC4B6] text-white font-display font-extrabold text-xl active:scale-[.99] transition">{t.seeKiko}</button>
          </div>
          <button onClick={() => { sfx.click(); setScreen("map"); }} className="tap mt-3 w-full min-h-[56px] rounded-full bg-white border-2 border-slate-200 font-display font-bold text-lg">{t.backToMap}</button>
        </main>
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  if (screen === "companion") {
    const pctNext = nextStage ? Math.min(100, Math.round(((completedCount - companionStage.minLevels) / (nextStage.minLevels - companionStage.minLevels)) * 100)) : 100;
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden">
        <TopBar title={t.companionBook} onBack={() => setScreen("map")} />
        <main className="mx-auto max-w-3xl px-4 py-5 pb-32">
          <section className="bg-white rounded-[32px] border-4 border-[#2EC4B6] p-5 text-center shadow-sm">
            <div className="w-56 h-48 mx-auto anim-floaty"><CompanionArt accessory={companionStage.accessory} className="w-full h-full" /></div>
            <h2 className="font-display font-extrabold text-3xl">{lang === "fil" ? companionStage.labelFil : companionStage.labelEn}</h2>
            <p className="font-bold text-slate-500">{completedCount} {lang === "fil" ? "mga level na natapos" : "levels completed"} • {starsTotal} {t.stars}</p>
            {nextStage ? (
              <div className="mt-4 text-left">
                <p className="text-sm font-bold text-slate-600 mb-1">{lang === "fil" ? `Susunod: ${nextStage.labelFil} (${nextStage.minLevels} levels)` : `Next: ${nextStage.labelEn} (${nextStage.minLevels} levels)`}</p>
                <div className="h-5 rounded-full bg-slate-100 overflow-hidden"><div className="h-full bg-[#2EC4B6] rounded-full transition-all" style={{ width: `${pctNext}%` }} /></div>
              </div>
            ) : <p className="mt-3 font-display font-bold text-[#2EC4B6]">{lang === "fil" ? "Lahat ng palamuti ay nakuha na!" : "All accessories unlocked!"}</p>}
          </section>

          <h3 className="font-display font-extrabold text-2xl mt-6 mb-3">{lang === "fil" ? "Aking mga sticker" : "My stickers"} ({stickers.length}/{GAME_DATA.stickers.length})</h3>
          <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
            {GAME_DATA.stickers.map((s) => {
              const got = stickers.includes(s.id);
              return (
                <div key={s.id} className={`rounded-3xl border-4 p-2 text-center ${got ? "bg-white border-amber-200" : "bg-slate-100 border-slate-200 opacity-60"}`}>
                  <div className="w-full aspect-square"><StickerArt id={s.id} color={got ? s.color : "#CBD5E1"} className="w-full h-full" /></div>
                  <p className="text-[11px] font-display font-bold leading-tight mt-1">{got ? (lang === "fil" ? s.labelFil : s.labelEn) : "?"}</p>
                </div>
              );
            })}
          </div>
        </main>
        <BottomNav active="companion" />
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  if (screen === "assigned") {
    const assigned = GAME_DATA.assignedWordIds.map((id) => {
      for (const w of GAME_DATA.worlds) { const f = w.words.find((x) => x.id === id); if (f) return { ...f, world: w }; }
      return null;
    }).filter(Boolean) as (typeof GAME_DATA.worlds[0]["words"][0] & { world: typeof GAME_DATA.worlds[0] })[];
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden">
        <TopBar title={t.assignedList} onBack={() => setScreen("map")} />
        <main className="mx-auto max-w-3xl px-4 py-5 pb-32">
          <section className="bg-[#9B7EDE] text-white rounded-[28px] p-5 shadow-sm">
            <p className="text-sm font-bold opacity-90">{t.assignedBy}</p>
            <h2 className="font-display font-extrabold text-3xl">{GAME_DATA.therapist.name}</h2>
            <p className="font-bold opacity-90">{GAME_DATA.therapist.roleEn} • {GAME_DATA.therapist.targetSound} {lang === "fil" ? GAME_DATA.therapist.focusFil : GAME_DATA.therapist.focusEn}</p>
            <p className="mt-2 inline-block bg-white text-[#9B7EDE] font-display font-bold rounded-full px-3 py-1 text-sm">{t.due} {lang === "fil" ? GAME_DATA.therapist.dueDateFil : GAME_DATA.therapist.dueDateEn}</p>
            <p className="mt-3 font-semibold opacity-95 leading-relaxed">{lang === "fil" ? GAME_DATA.therapist.noteFil : GAME_DATA.therapist.noteEn}</p>
          </section>

          <div className="mt-4 space-y-2">
            {assigned.map((wd) => {
              const done = wordsPracticed.has(wd.id);
              return (
                <button key={wd.id} onClick={() => openWord(wd.world.id, wd.id)} className={`tap w-full min-h-[72px] bg-white rounded-3xl border-4 p-3 flex items-center gap-3 text-left active:scale-[.99] transition ${done ? "border-[#2EC4B6]" : "border-slate-200"}`}>
                  <div className="w-20 h-14 shrink-0"><WordArt art={wd.art} className="w-full h-full" /></div>
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-extrabold text-2xl leading-none">{wd.word} <span className="text-sm text-slate-400 font-bold">{wd.syllables}</span></p>
                    <p className="text-sm font-bold text-slate-500">{lang === "fil" ? wd.world.nameFil : wd.world.nameEn} • {wd.targetSound}</p>
                  </div>
                  <span className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 ${done ? "bg-[#2EC4B6] text-white" : "bg-slate-100 text-slate-400"}`}>{I.check("w-6 h-6")}</span>
                </button>
              );
            })}
          </div>
          <p className="mt-4 text-center text-sm font-bold text-slate-400">{t.noFailNote}</p>
        </main>
        <BottomNav active="assigned" />
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  if (screen === "parentGate") {
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden flex flex-col">
        <TopBar title={t.parentGateTitle} onBack={() => setScreen("map")} />
        <main className="flex-1 mx-auto w-full max-w-md px-4 py-8 flex flex-col justify-center">
          <div className="bg-white rounded-[32px] border-4 border-[#9B7EDE] p-6 text-center shadow-sm">
            <div className="w-16 h-16 mx-auto rounded-full bg-[#EAE3FF] text-[#9B7EDE] flex items-center justify-center mb-3">{I.lock("w-8 h-8")}</div>
            <h2 className="font-display font-extrabold text-3xl">{t.parentGateTitle}</h2>
            <p className="font-bold text-slate-500 mt-1">{t.parentGateText}</p>
            <p className="font-display font-extrabold text-5xl mt-5 tracking-wide">{gateA} + {gateB} = ?</p>
            <input value={gateInput} onChange={(e) => { setGateInput(e.target.value.replace(/[^0-9]/g, "").slice(0, 3)); setGateError(false); }} inputMode="numeric" placeholder="?" aria-label="Answer" className="tap mt-4 w-full min-h-[64px] rounded-2xl border-2 border-slate-200 bg-[#FFFBEB] text-center font-display font-extrabold text-3xl" />
            {gateError && <p className="mt-2 font-display font-bold text-[#FF6B6B]" role="alert">{t.wrongAnswer}</p>}
            <button onClick={checkGate} className="tap mt-4 w-full min-h-[60px] rounded-full bg-[#9B7EDE] text-white font-display font-extrabold text-xl active:scale-[.99] transition">{t.check}</button>
          </div>
        </main>
      </div>
    );
  }

  if (screen === "parent") {
    const mins = Math.max(1, Math.round(sessionSeconds / 60));
    const week = [2, 4, 3, 5, 1, 4, mins].map((v, i) => ({ d: ["M", "T", "W", "T", "F", "S", "S"][i], v: Math.min(v, 6) }));
    return (
      <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden">
        <TopBar title={t.parentArea} onBack={() => setScreen("map")} />
        <main className="mx-auto max-w-3xl px-4 py-5 pb-32 space-y-4">
          <section className="bg-white rounded-[28px] border-4 border-amber-200 p-5">
            <h2 className="font-display font-extrabold text-2xl mb-3">{t.summaryTitle}</h2>
            <div className="grid grid-cols-3 gap-2 text-center">
              {[
                { v: wordsPracticed.size, l: t.wordsPracticed },
                { v: ratingsCount, l: t.ratingsGiven },
                { v: mins, l: t.minutesPlayed },
              ].map((s) => (
                <div key={s.l} className="bg-[#FFFBEB] rounded-2xl p-3 border-2 border-amber-100">
                  <p className="font-display font-extrabold text-3xl">{s.v}</p>
                  <p className="text-xs font-bold text-slate-500 leading-tight">{s.l}</p>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <p className="text-sm font-bold text-slate-500 mb-2">{t.weekly}</p>
              <div className="flex items-end gap-2 h-24">
                {week.map((d, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className={`w-full rounded-t-xl ${i === 6 ? "bg-[#FF6B6B]" : "bg-[#2EC4B6]"}`} style={{ height: `${(d.v / 6) * 100}%` }} />
                    <span className="text-xs font-bold text-slate-500">{d.d}</span>
                  </div>
                ))}
              </div>
            </div>
            <button onClick={sendToTherapist} className="tap mt-4 w-full min-h-[60px] rounded-full bg-[#2EC4B6] text-white font-display font-extrabold text-lg active:scale-[.99] transition">
              {sent ? `✓ ${t.sent}` : t.sendTherapist}
            </button>
            <p className="text-xs font-bold text-slate-400 text-center mt-2">{t.sendMock}</p>
          </section>

          <section className="bg-white rounded-[28px] border-4 border-[#D9F5F1] p-5">
            <h2 className="font-display font-extrabold text-2xl mb-3">{t.settings}</h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-3">
                <span className="font-display font-bold text-lg">{t.language}</span>
                <LangToggle />
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="font-display font-bold text-lg">{t.sound}</span>
                <button onClick={() => setMutedState((m) => !m)} className={`tap min-h-[52px] px-5 rounded-full font-display font-extrabold ${muted ? "bg-slate-200 text-slate-600" : "bg-[#FFC93C] text-[#2D3142]"}`}>{muted ? t.off : t.on}</button>
              </div>
              <button onClick={resetProgress} className="tap w-full min-h-[56px] rounded-full bg-[#FFE0E0] text-[#9F1239] font-display font-extrabold text-lg active:scale-[.99] transition">{t.reset}</button>
            </div>
          </section>

          <section className="bg-white rounded-[28px] border-4 border-[#EAE3FF] p-5">
            <h2 className="font-display font-extrabold text-2xl mb-2">{t.privacy}</h2>
            <p className="font-semibold text-slate-600 leading-relaxed">{t.privacyText}</p>
            <ul className="mt-3 space-y-1.5 font-semibold text-slate-600">
              <li className="flex gap-2"><span className="text-[#2EC4B6]">{I.check("w-5 h-5 shrink-0")}</span>{lang === "fil" ? "Walang ads, walang external link, walang bayad." : "No ads, no external links, no purchases."}</li>
              <li className="flex gap-2"><span className="text-[#2EC4B6]">{I.check("w-5 h-5 shrink-0")}</span>{lang === "fil" ? "Ang audio ay hindi ina-upload o sine-save." : "Audio is never uploaded or saved."}</li>
              <li className="flex gap-2"><span className="text-[#2EC4B6]">{I.check("w-5 h-5 shrink-0")}</span>{lang === "fil" ? "Palayaw at avatar lamang ang ginagamit." : "Nickname and avatar only."}</li>
            </ul>
          </section>
        </main>
        <BottomNav active="parent" />
        {toast && <Toast msg={toast} />}
      </div>
    );
  }

  // summary
  const mins = Math.max(1, Math.round(sessionSeconds / 60));
  return (
    <div className="min-h-dvh bg-[#FFFBEB] overflow-x-hidden">
      <TopBar title={t.summaryTitle} onBack={() => setScreen("map")} />
      <main className="mx-auto max-w-3xl px-4 py-6 pb-32 text-center">
        <div className="w-40 h-36 mx-auto anim-floaty"><CompanionArt accessory={companionStage.accessory} className="w-full h-full" /></div>
        <h2 className="font-display font-extrabold text-3xl mt-2">{t.greatJob} {profile.nickname}!</h2>
        <div className="mt-5 grid grid-cols-3 gap-2 max-w-md mx-auto">
          {[
            { v: wordsPracticed.size, l: t.wordsPracticed },
            { v: ratingsCount, l: t.ratingsGiven },
            { v: mins, l: t.minutesPlayed },
          ].map((s) => (
            <div key={s.l} className="bg-white rounded-3xl border-4 border-amber-200 p-4">
              <p className="font-display font-extrabold text-4xl">{s.v}</p>
              <p className="text-xs font-bold text-slate-500 leading-tight mt-1">{s.l}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 bg-white rounded-3xl border-4 border-[#D9F5F1] p-4 max-w-md mx-auto text-left">
          <p className="font-display font-bold">{t.assignedBy} {GAME_DATA.therapist.name}</p>
          <p className="text-sm font-bold text-slate-500">{GAME_DATA.therapist.targetSound} • {completedCount} {lang === "fil" ? "mga level na natapos" : "levels completed"} • {starsTotal} {t.stars}</p>
        </div>
        <button onClick={sendToTherapist} className="tap mt-5 w-full max-w-md min-h-[64px] rounded-full bg-[#2EC4B6] text-white font-display font-extrabold text-xl active:scale-[.99] transition">
          {sent ? `✓ ${t.sent}` : t.sendTherapist}
        </button>
        <p className="text-xs font-bold text-slate-400 mt-2">{t.sendMock}</p>
        <button onClick={() => { sfx.click(); setScreen("map"); }} className="tap mt-4 w-full max-w-md min-h-[60px] rounded-full bg-[#FF6B6B] text-white font-display font-extrabold text-xl active:scale-[.99] transition">{t.backToMap}</button>
      </main>
      <BottomNav active="map" />
      {toast && <Toast msg={toast} />}
    </div>
  );
}

function Toast({ msg }: { msg: string }) {
  return (
    <div className="fixed bottom-24 inset-x-0 z-50 flex justify-center px-4 pointer-events-none" role="status">
      <div className="anim-pop bg-[#2D3142] text-white font-display font-bold text-base px-5 py-3 rounded-full shadow-xl max-w-md text-center">{msg}</div>
    </div>
  );
}
